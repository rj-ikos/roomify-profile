Place custom themes for your project in this directory. The whole directory
will be moved inside `sites/default` at the end of the build process.

Don't place contributed themes or base themes in here, add them to the
`project.make` file in the root directory.
