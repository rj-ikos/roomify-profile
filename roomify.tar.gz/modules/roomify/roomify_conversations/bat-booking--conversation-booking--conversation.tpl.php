<?php

/**
 * @file
 */
?>

<div class="<?php print $classes; ?> clearfix">
  <div class="content"<?php print $content_attributes; ?>>
    <?php print render($content); ?>
  </div>
</div>
