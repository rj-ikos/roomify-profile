<?php

/**
 * @file
 */
?>

<div class="<?php print $classes; ?>"<?php print $attributes; ?>>
  <div class="content"<?php print $content_attributes; ?>>
    <?php print $location_map; ?>
  </div>
</div>
