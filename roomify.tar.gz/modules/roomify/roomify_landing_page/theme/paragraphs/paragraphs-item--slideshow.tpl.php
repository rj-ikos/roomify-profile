<?php

/**
 * @file
 */
?>

<div class="<?php print $classes; ?>"<?php print $attributes; ?>>
  <div class="content"<?php print $content_attributes; ?>>
    <?php print $slideshow; ?>
  </div>
</div>
