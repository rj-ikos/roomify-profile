These are for reference only. This folder is not needed in the build.
Copy and paste the minimized version directly into your markup.

To add a new icon, drag it to this folder, then restart gulp
and it will be minimized. Used minimized code in markup.
