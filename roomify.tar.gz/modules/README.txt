Place custom modules for your project in this directory. The whole directory
will be moved inside `sites/default` at the end of the build process.

Don't place contributed modules in here, add them to the `project.make`
file in the root directory.
